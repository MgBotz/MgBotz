exports.allmenu = (prefix) => {
return `━━━━━━━━━━━━━━━━━━━
_*OTHER MENU*_
• ${prefix}ping
• ${prefix}simi
• ${prefix}rules
• ${prefix}listpc
• ${prefix}listgc
• ${prefix}daftar
• ${prefix}owner
• ${prefix}menfes
• ${prefix}runtime
• ${prefix}cariteman
━━━━━━━━━━━━━━━
_*TOOLS MENU*_
• ${prefix}tts
• ${prefix}isgd
• ${prefix}cuttly
• ${prefix}tinyurl
• ${prefix}nulis
• ${prefix}toimg
• ${prefix}obfus
• ${prefix}ssweb
• ${prefix}kalkulator
━━━━━━━━━━━━━━━
_*SET PROSES/DONE*_
• ${prefix}setdone
• ${prefix}changedone
• ${prefix}delsetdone
• ${prefix}setproses
• ${prefix}delsetproses
• ${prefix}changeproses
━━━━━━━━━━━━━━━
_*STORE MENU*_
• ${prefix}list
• ${prefix}addlist
• ${prefix}dellist
• ${prefix}done
• ${prefix}proses
• ${prefix}kali
• ${prefix}bagi
• ${prefix}kurang
• ${prefix}tambah
━━━━━━━━━━━━━━━
_*TOPUP GAMES*_
• ${prefix}topupff 
• ${prefix}topupml
━━━━━━━━━━━━━━━
_*GROUP MENU*_
• ${prefix}add
• ${prefix}kick
• ${prefix}open
• ${prefix}close
• ${prefix}group
• ${prefix}tagall
• ${prefix}delete
• ${prefix}revoke
• ${prefix}antilink
• ${prefix}hidetag
• ${prefix}demote
• ${prefix}setdesc
• ${prefix}linkgrup
• ${prefix}promote
• ${prefix}setppgrup
• ${prefix}setnamegc
━━━━━━━━━━━━━━━
_*OWNER MENU*_
• ${prefix}bc
• ${prefix}leave
• ${prefix}creategc
• ${prefix}sendsesi
• ${prefix}setppbot
• ${prefix}broadcast
• ${prefix}bugpc *628xxx*
• ${prefix}buggc *_only grup_*
• ${prefix}inibug *_only grup_*
• ${prefix}sendbug *628xxx*
━━━━━━━━━━━━━━━
_*DOWNLOADER*_
• ${prefix}play
• ${prefix}tiktok
• ${prefix}ytmp3
• ${prefix}ytmp4
• ${prefix}gitclone
• ${prefix}mediafire
━━━━━━━━━━━━━━━`
}